import { Product } from './product.model';
import { SimpleDataSource } from './datasource.model';

export class Model {
  private dataSource: SimpleDataSource;
  private products: Product[];
  private locator: (p: Product, id: number) => boolean = (p, id) => p.id === id;

  constructor() {
    this.dataSource = new SimpleDataSource();
    this.products = new Array<Product>();
    this.dataSource.getData().forEach((p) => this.products.push(p));
  }

  getProducts(): Product[] {
    return this.products;
  }

  getProduct(id: number): Product | undefined {
    return this.products.find((p) => this.locator(p, id));
  }

  saveProduct(product: Product): void {
    if (product.id === 0 || product.id === null || product.id === undefined) {
      product.id = this.generateId();
      this.products.push(product);
    } else {
      let index = this.products.findIndex((p) => this.locator(p, product.id!));
      if (index !== -1) this.products.splice(index, 1, product);
    }
  }

  deleteProduct(id: number): void {
    let index = this.products.findIndex((p) => this.locator(p, id));
    if (index !== -1) this.products.splice(index, 1);
  }

  private generateId(): number {
    let candidate = 100;
    while (this.getProduct(candidate) !== null) {
      candidate++;
    }
    return candidate;
  }
}
